plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.jvn.roulette50"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.jvn.roulette50"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
