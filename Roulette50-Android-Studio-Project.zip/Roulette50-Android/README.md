# Roulette 50 — Android Studio project

This project wraps the standalone Roulette 50 HTML app in an offline Android WebView.
JavaScript and DOM storage are enabled so the roulette analytics and localStorage history work on-device.

## Build an APK
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this folder (`Roulette50-Android`) in Android Studio.
3. Allow Gradle sync to finish.
4. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will show the generated APK location, usually `app/build/outputs/apk/debug/app-debug.apk`.

For a shareable release APK, use **Build → Generate Signed Bundle / APK** and create a signing key.

No network permission or internet connection is required. App data is stored locally on the device.
